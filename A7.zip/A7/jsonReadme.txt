The button 'Load Sample JSON' was added to test the loading from the json data.

First I created a jQuery that pulled the puzzle array and loaded the board with the Sample data, but the grading criteria said i had to use the XMLHttpRequest.
I then recreated the functionality to use that instead of jQuery.  Everything should be good on the criteria, but if I missed something please let me fix it.
This one was a little confusing to follow and know what all I had to do.
